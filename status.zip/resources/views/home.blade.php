<x-layouts.app>

 <livewire:service-status />

</x-layouts.app>
